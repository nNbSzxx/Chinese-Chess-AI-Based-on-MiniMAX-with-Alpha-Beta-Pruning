package chess.AI;

import chess.board.ChessBoard;
import chess.util.Step;

public class ChessEngine {
	public Step generateAMove(ChessBoard board) {
		return new Step(-1, -1, -1, -1);
	}
	public boolean askForPeace(ChessBoard board) {
		return false;
	}
}
