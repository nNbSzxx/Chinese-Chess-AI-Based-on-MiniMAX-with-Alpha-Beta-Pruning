package chess.AI;

import chess.board.ChessBoard;
import chess.util.Step;

public interface Searchable {
	int evaluate(ChessBoard board);
	Step[] generateAllNextState(ChessBoard board);
	boolean isEndState(ChessBoard board);
}
