package chess.piece;

import java.util.ArrayList;
import java.util.List;



import chess.board.ChessBoard;
import chess.util.Step;

public class Horse extends ChessPieces{

	public Horse(int iniX, int iniY, boolean iniIsRed, boolean iniIsAlive, String iniName) {
		super(iniX, iniY, iniIsRed, iniIsAlive, iniName);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean isLegalMove(ChessBoard board, int toX, int toY) {
		// TODO Auto-generated method stub
		if(!isMyTurn(board))
		{
			return false;
		}else if (this.getX() == toX &&this.getY() == toY) {
			return false;
		}else if (!isDestinationLegal(board, toX, toY)) {
			return false;
		}else {
			if (!((Math.abs(toX - this.getX())==2 && Math.abs(toY - this.getY())==1)||
					(Math.abs(toX - this.getX())== 1&&Math.abs(toY) - this.getY() == 2))) {
				return false;
			}
			if (Math.abs(toX - this.getX()) == 2) {
				int hx;
				int hy;
				hx = (toX + this.getX()) / 2;
				hy = this.getY();
				if(board.getPiece(hx, hy)!= null)
					return false;
			}else if(Math.abs(toY - this.getY()) == 2) 
			{
				int hx;
				int hy;
				hx = this.getX();
				hy = (this.getY() + toY);
				if(board.getPiece(hx, hy)!= null)
					return false;
			}
		}
		return true;
	}

	@Override
	public List<Step> getNextMove(ChessBoard board) {
		// TODO Auto-generated method stub
		List<Step> list = new ArrayList<Step>();
		//ͬһ�������ĸ��ط��������ȵĵط���ÿһ���ط�Ҫ��û�����ӵĻ����Բ��������߷���
		//ֻ����λ���Ƿ�����Լ�����λ���Ƿ��м���������
		//���Ϸ������ȵ�λ�ý��м��
		if(board.getPiece(this.getX() - 1, this.getY()) == null) 
		{
			if(this.getX() - 2 >= 0 && this.getY() + 1 <= 8 && 
					isDestinationLegal(board, this.getX() -2, this.getY() + 1))
				list.add(new Step(this.getX(), this.getY(), this.getX() - 2, this.getY()+ 1));
			if(this.getX() - 2 >= 0 && this.getY() - 1 >= 0 && 
					isDestinationLegal(board, this.getX() -2, this.getY() - 1))
				list.add(new Step(this.getX(), this.getY(), this.getX() - 2, this.getY()- 1));
		}
		//���·�������λ�ý��м��
		if(board.getPiece(this.getX() + 1, this.getY()) == null) 
		{
			if(this.getX() <10 && this.getY() < 9 && 
					isDestinationLegal(board, this.getX() + 2, this.getY() + 1))
				list.add(new Step(this.getX(), this.getY(), this.getX() - 2, this.getY()+ 1));
			if(this.getX() + 2 < 10 && this.getY() >= 0 && 
					isDestinationLegal(board, this.getX() +2, this.getY() - 1))
				list.add(new Step(this.getX(), this.getY(), this.getX() - 2, this.getY()- 1));
		}
		//���Ҳ�������λ�ý��м��
		if(board.getPiece(this.getX(), this.getY()+1) == null) 
		{
			if(this.getX() >= 0&&this.getY() < 9&&isDestinationLegal(board, this.getX() -1, this.getY() +2))
				list.add(new Step(this.getX(), this.getY(), this.getX() -1, this.getY()+2));
			if(this.getX() <10&&this.getY()< 9&&isDestinationLegal(board, this.getX() +1, this.getY() +2))
				list.add(new Step(this.getX(), this.getY(), this.getX() - 1, this.getY()+2));
		}
		//�����������λ�ý��м��
		if(board.getPiece(this.getX(), this.getY()-1) == null) 
		{
			if(this.getX() >= 0&&this.getY() >= 0&&isDestinationLegal(board, this.getX() -1, this.getY() -2))
				list.add(new Step(this.getX(), this.getY(), this.getX() -1, this.getY() - 2));
			if(this.getX() <10&&this.getY() >=0&&isDestinationLegal(board, this.getX() +1, this.getY() - 2))
				list.add(new Step(this.getX(), this.getY(), this.getX() +1, this.getY()- 2));
		}
		return null;
	}

	

	@Override
	public String getImagePath() {
		// TODO Auto-generated method stub
		return null;
	}

}
