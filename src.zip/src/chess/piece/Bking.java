package chess.piece;

import java.util.ArrayList;
import java.util.List;

import chess.board.ChessBoard;
import chess.util.Step;

public class Bking extends ChessPieces{

	public Bking(int iniX, int iniY, boolean iniIsRed, boolean iniIsAlive, String iniName) {
		super(iniX, iniY, iniIsRed, iniIsAlive, iniName);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean isLegalMove(ChessBoard board, int toX, int toY) {
		// TODO Auto-generated method stub
		if(!isMyTurn(board)) 
		{
			return false;
		}else if (this.getX() == toX&&this.getY() == toY) {
			return false;
		}else if (!isDestinationLegal(board, toX, toY)) {
			return false;
		}else if (toX > 2 || toY < 3||toY > 5) {//�����Ź�
			return false;
		}else if (Math.abs(toY - this.getY()) + Math.abs(toX- this.getX())  != 1) {
			return false;
		}else {//��˧���ܶ�������
			//��Ҫ����һ�������ҵ�Bking�� λ������
			@SuppressWarnings("unused")
			int bx = 0;
			int by = 0;
			for(int i = 3;i < 6;i++) 
			{
				for(int j = 0;j < 3;j++) 
				{
					if(board.getPiece(i, j).getName() == "Rking") 
						bx = i;by = j;
				}
			}
			if(by == toY) 
			{
				if(this.piecesInStraightWay(board, toX, toY) == 0)
					return false;
			}
		}
		
		return true;
	}

	@Override
	public List<Step> getNextMove(ChessBoard board) {
		// TODO Auto-generated method stub
		List<Step> list = new ArrayList<Step>();
		for(int i = 0;i< 3;i++) //�ԾŹ�����б������������������ļӵ�list��
		{
			for(int j = 3;j < 6;j++) 
			{
				if(this.isLegalMove(board, i, j)) {
					list.add(new Step(this.getX(), this.getY(), i, j));
				}
			}
		}
		return list;
	}

	@Override
	public String getImagePath() {
		// TODO Auto-generated method stub
		return null;
	}

}
