package chess.view;

import chess.board.ChessBoard;
import chess.util.Step;

public class _ChessView {
	private ChessBoard board;
	public _ChessView(ChessBoard iniChessBoard) {
		// TODO Auto-generated constructor stub
		board = iniChessBoard;
		draw();
	}
	
	// ���Ƶ�ǰ����
	public void draw() {
		
	}
	
	
}
